import { Flame, Wrench, Truck, Users, ClipboardCheck, FileText, Recycle, SprayCan, Mountain, AlertTriangle } from "lucide-react";

const services = [
  {
    icon: Flame,
    title: "Mobile Incineration",
    description: "Safe, on-site waste incineration services with environmental compliance"
  },
  {
    icon: Wrench,
    title: "Septic Tank Cleaning",
    description: "Professional septic tank maintenance and cleaning services"
  },
  {
    icon: Truck,
    title: "Suction Bowser Services",
    description: "Efficient liquid waste removal and transportation"
  },
  {
    icon: Users,
    title: "Waste Handling & Transportation",
    description: "Comprehensive waste collection and transport solutions"
  },
  {
    icon: ClipboardCheck,
    title: "Waste Management Consultation",
    description: "Expert guidance on waste management strategies"
  },
  {
    icon: FileText,
    title: "Document Disposal",
    description: "Secure disposal of confidential and non-confidential documents"
  },
  {
    icon: Recycle,
    title: "Plastic & Material Recycling",
    description: "Sustainable recycling solutions for various materials"
  },
  {
    icon: SprayCan,
    title: "Fumigation & Pest Control",
    description: "Professional pest control and fumigation services"
  },
  {
    icon: Mountain,
    title: "Landfill Storage Solutions",
    description: "Safe and compliant landfill storage management"
  },
  {
    icon: AlertTriangle,
    title: "Hazardous Waste Handling",
    description: "Specialized handling and transport of hazardous materials"
  }
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-accent">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Our <span className="gradient-text">Services</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive waste management solutions tailored to your needs
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div 
                key={index}
                className="service-card card-3d p-6 rounded-xl cursor-pointer"
                data-testid={`service-card-${index}`}
              >
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-8 h-8 text-background" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{service.title}</h3>
                  <p className="text-muted-foreground text-sm">{service.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
