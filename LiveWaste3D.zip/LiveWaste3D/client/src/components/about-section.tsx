import { Target, Eye, Leaf } from "lucide-react";

export default function AboutSection() {
  return (
    <section id="about" className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <h2 className="text-4xl md:text-5xl font-bold">
              About <span className="gradient-text">Live Waste Solution</span>
            </h2>
            
            <div className="space-y-6">
              <div className="bg-card border border-border rounded-xl p-6 hover:border-primary transition-colors">
                <h3 className="text-2xl font-semibold mb-3 text-primary flex items-center">
                  <Target className="w-6 h-6 mr-2" />
                  Our Mission
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  To deliver safe, reliable, and innovative waste solutions that protect the environment and improve public health.
                </p>
              </div>
              
              <div className="bg-card border border-border rounded-xl p-6 hover:border-secondary transition-colors">
                <h3 className="text-2xl font-semibold mb-3 text-secondary flex items-center">
                  <Eye className="w-6 h-6 mr-2" />
                  Our Vision
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  To become Pakistan's most trusted and technologically advanced waste management company.
                </p>
              </div>
            </div>
          </div>
          
          <div className="flex justify-center">
            <div className="relative">
              <div className="w-80 h-80 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-full flex items-center justify-center animate-pulse">
                <div className="w-60 h-60 bg-gradient-to-br from-primary/40 to-secondary/40 rounded-full flex items-center justify-center">
                  <div className="w-40 h-40 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
                    <Leaf className="w-16 h-16 text-background" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
