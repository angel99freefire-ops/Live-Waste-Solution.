import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Recycle, Menu, X } from "lucide-react";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 w-full bg-background/90 backdrop-blur-md border-b border-border z-50">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
              <Recycle className="w-6 h-6 text-background" />
            </div>
            <span className="text-xl font-bold gradient-text">Live Waste Solution</span>
          </Link>
          
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('services')} 
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="nav-services"
            >
              Services
            </button>
            <button 
              onClick={() => scrollToSection('about')} 
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="nav-about"
            >
              About
            </button>
            <button 
              onClick={() => scrollToSection('clients')} 
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="nav-clients"
            >
              Clients
            </button>
            <button 
              onClick={() => scrollToSection('contact')} 
              className="text-muted-foreground hover:text-primary transition-colors"
              data-testid="nav-contact"
            >
              Contact
            </button>
            <Button 
              className="bg-primary text-primary-foreground glow-green hover:bg-primary/90"
              onClick={() => scrollToSection('contact')}
              data-testid="button-request-quote"
            >
              Request Quote
            </Button>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            data-testid="button-menu-toggle"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-border">
            <div className="flex flex-col space-y-4 pt-4">
              <button 
                onClick={() => scrollToSection('services')} 
                className="text-muted-foreground hover:text-primary transition-colors text-left"
                data-testid="nav-mobile-services"
              >
                Services
              </button>
              <button 
                onClick={() => scrollToSection('about')} 
                className="text-muted-foreground hover:text-primary transition-colors text-left"
                data-testid="nav-mobile-about"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection('clients')} 
                className="text-muted-foreground hover:text-primary transition-colors text-left"
                data-testid="nav-mobile-clients"
              >
                Clients
              </button>
              <button 
                onClick={() => scrollToSection('contact')} 
                className="text-muted-foreground hover:text-primary transition-colors text-left"
                data-testid="nav-mobile-contact"
              >
                Contact
              </button>
              <Button 
                className="bg-primary text-primary-foreground glow-green hover:bg-primary/90 w-full"
                onClick={() => scrollToSection('contact')}
                data-testid="button-mobile-request-quote"
              >
                Request Quote
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
