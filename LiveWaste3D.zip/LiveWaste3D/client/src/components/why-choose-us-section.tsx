import { useEffect, useState } from "react";
import { Tag, Award, Shield, Zap, CheckCircle, Handshake } from "lucide-react";

export default function WhyChooseUsSection() {
  const [stats, setStats] = useState({
    years: 0,
    clients: 0,
    waste: 0,
    emergency: 0
  });

  const [hasAnimated, setHasAnimated] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !hasAnimated) {
            setHasAnimated(true);
            animateCounters();
          }
        });
      },
      { threshold: 0.5 }
    );

    const statsSection = document.getElementById('stats-section');
    if (statsSection) {
      observer.observe(statsSection);
    }

    return () => observer.disconnect();
  }, [hasAnimated]);

  const animateCounters = () => {
    const targets = { years: 15, clients: 500, waste: 10, emergency: 24 };
    const durations = { years: 2000, clients: 2500, waste: 2000, emergency: 1000 };

    Object.entries(targets).forEach(([key, target]) => {
      const duration = durations[key as keyof typeof durations];
      const increment = target / (duration / 50);
      let current = 0;

      const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
          current = target;
          clearInterval(timer);
        }
        setStats(prev => ({ ...prev, [key]: Math.floor(current) }));
      }, 50);
    });
  };

  return (
    <section id="why-choose-us" className="py-20 bg-accent">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Why Choose <span className="gradient-text">Us</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Certified excellence and proven results in waste management
          </p>
        </div>
        
        {/* Certifications */}
        <div className="flex justify-center gap-8 mb-16">
          <div className="bg-card border border-border rounded-xl p-6 text-center hover:border-primary transition-colors">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <Tag className="w-8 h-8 text-primary-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-primary">SEPA Certified</h3>
          </div>
          
          <div className="bg-card border border-border rounded-xl p-6 text-center hover:border-secondary transition-colors">
            <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-secondary-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-secondary">BEPA Certified</h3>
          </div>
        </div>
        
        {/* Stats Counter */}
        <div id="stats-section" className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          <div className="text-center" data-testid="stat-years">
            <div className="text-4xl md:text-5xl font-bold gradient-text mb-2">
              {stats.years}+
            </div>
            <p className="text-muted-foreground">Years in Service</p>
          </div>
          
          <div className="text-center" data-testid="stat-clients">
            <div className="text-4xl md:text-5xl font-bold gradient-text mb-2">
              {stats.clients}+
            </div>
            <p className="text-muted-foreground">Clients Served</p>
          </div>
          
          <div className="text-center" data-testid="stat-waste">
            <div className="text-4xl md:text-5xl font-bold gradient-text mb-2">
              {stats.waste}K+
            </div>
            <p className="text-muted-foreground">Tons of Waste Managed</p>
          </div>
          
          <div className="text-center" data-testid="stat-emergency">
            <div className="text-4xl md:text-5xl font-bold gradient-text mb-2">
              24/7
            </div>
            <p className="text-muted-foreground">Emergency Responses</p>
          </div>
        </div>
        
        {/* Features */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-background" />
            </div>
            <h3 className="font-semibold mb-2">Safety First</h3>
            <p className="text-sm text-muted-foreground">Highest safety standards</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-background" />
            </div>
            <h3 className="font-semibold mb-2">Fast Response</h3>
            <p className="text-sm text-muted-foreground">Quick service delivery</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-background" />
            </div>
            <h3 className="font-semibold mb-2">Compliance</h3>
            <p className="text-sm text-muted-foreground">Regulatory compliance</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
              <Handshake className="w-8 h-8 text-background" />
            </div>
            <h3 className="font-semibold mb-2">Reliability</h3>
            <p className="text-sm text-muted-foreground">Trusted partnerships</p>
          </div>
        </div>
      </div>
    </section>
  );
}
