import { Button } from "@/components/ui/button";
import { HelpCircle, Settings, Users } from "lucide-react";

export default function CTABlocks() {
  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 rounded-xl p-8 text-center hover:border-primary/40 transition-colors">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
              <HelpCircle className="w-8 h-8 text-primary-foreground" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Still Have Questions?</h3>
            <p className="text-muted-foreground mb-6">Get expert answers from our waste management specialists</p>
            <Button 
              className="bg-primary text-primary-foreground hover:bg-primary/90 w-full"
              onClick={scrollToContact}
              data-testid="button-cta-questions"
            >
              Ask an Expert
            </Button>
          </div>
          
          <div className="bg-gradient-to-br from-secondary/10 to-secondary/5 border border-secondary/20 rounded-xl p-8 text-center hover:border-secondary/40 transition-colors">
            <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
              <Settings className="w-8 h-8 text-secondary-foreground" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Need a Custom Solution?</h3>
            <p className="text-muted-foreground mb-6">We design tailored waste management plans for your specific needs</p>
            <Button 
              className="bg-secondary text-secondary-foreground hover:bg-secondary/90 w-full"
              onClick={scrollToContact}
              data-testid="button-cta-custom"
            >
              Get Custom Plan
            </Button>
          </div>
          
          <div className="bg-gradient-to-br from-primary/10 to-secondary/10 border border-border rounded-xl p-8 text-center hover:border-primary/20 transition-colors">
            <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-6">
              <Users className="w-8 h-8 text-background" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Ready to Join Our Satisfied Clients?</h3>
            <p className="text-muted-foreground mb-6">Start your journey with Pakistan's leading waste management company</p>
            <Button 
              className="bg-gradient-to-r from-primary to-secondary text-background hover:opacity-90 w-full"
              onClick={scrollToContact}
              data-testid="button-cta-partnership"
            >
              Start Partnership
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
