import { useEffect, useState } from "react";

const clientLogos = [
  "Acme Corp",
  "TechGlobal",
  "IndustrialPro",
  "EcoSystems",
  "UrbanDev",
  "GreenTech",
  "CityWorks",
  "MetroBuilds"
];

export default function ClientsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % clientLogos.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section id="clients" className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Our <span className="gradient-text">Clients</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Trusted by leading organizations across Pakistan
          </p>
        </div>
        
        <div className="relative overflow-hidden">
          <div className="flex justify-center items-center space-x-8 min-h-24">
            {clientLogos.map((client, index) => (
              <div 
                key={index}
                className={`w-32 h-20 bg-card border border-border rounded-lg flex items-center justify-center transition-all duration-500 ${
                  index === currentIndex ? 'opacity-100 scale-110 border-primary' : 'opacity-60 scale-100'
                }`}
                data-testid={`client-logo-${index}`}
              >
                <span className="text-muted-foreground text-sm font-medium text-center px-2">
                  {client}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-center mt-8 space-x-2">
          {clientLogos.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`w-2 h-2 rounded-full transition-colors ${
                index === currentIndex ? 'bg-primary' : 'bg-muted'
              }`}
              data-testid={`client-indicator-${index}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
