import { Link } from "wouter";
import { Recycle } from "lucide-react";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-accent border-t border-border py-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-secondary rounded-lg flex items-center justify-center">
                <Recycle className="w-6 h-6 text-background" />
              </div>
              <span className="text-xl font-bold gradient-text">Live Waste Solution</span>
            </Link>
            <p className="text-lg font-semibold text-primary mb-2">Leading Waste Management Experts</p>
            <p className="text-muted-foreground mb-4">"Together, we can build a cleaner, safer future."</p>
            <p className="text-sm text-muted-foreground">
              Committed to delivering innovative, safe, and environmentally responsible waste management solutions across Pakistan.
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => scrollToSection('services')} 
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-link-services"
                >
                  Services
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('about')} 
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-link-about"
                >
                  About Us
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('clients')} 
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-link-clients"
                >
                  Our Clients
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('contact')} 
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-link-contact"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>
          
          {/* Services */}
          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => scrollToSection('services')} 
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-service-incineration"
                >
                  Mobile Incineration
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('services')} 
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-service-septic"
                >
                  Septic Tank Cleaning
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('services')} 
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-service-bowser"
                >
                  Suction Bowser
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('faq')} 
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                  data-testid="footer-service-emergency"
                >
                  Emergency Services
                </button>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex space-x-6 mb-4 md:mb-0">
            <a 
              href="#" 
              className="text-sm text-muted-foreground hover:text-primary transition-colors"
              data-testid="footer-link-privacy"
            >
              Privacy Policy
            </a>
            <a 
              href="#" 
              className="text-sm text-muted-foreground hover:text-primary transition-colors"
              data-testid="footer-link-terms"
            >
              Terms of Service
            </a>
            <a 
              href="#" 
              className="text-sm text-muted-foreground hover:text-primary transition-colors"
              data-testid="footer-link-legal"
            >
              Legal
            </a>
          </div>
          <p className="text-sm text-muted-foreground">
            &copy; 2024 Live Waste Solution. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
