import { User, Star } from "lucide-react";

const testimonials = [
  {
    name: "Ahmed Khan",
    role: "Operations Manager",
    content: "Exceptional service quality and professional team. They handle our waste management needs efficiently and reliably.",
    rating: 5
  },
  {
    name: "Sarah Ali",
    role: "Facility Director",
    content: "Their emergency response service saved us during a critical situation. Highly recommend their expertise.",
    rating: 5
  },
  {
    name: "Muhammad Hassan",
    role: "Environmental Manager",
    content: "Professional approach to hazardous waste management with full compliance. Outstanding service quality.",
    rating: 5
  }
];

export default function TestimonialsSection() {
  return (
    <section id="testimonials" className="py-20 bg-accent">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            What Our Clients <span className="gradient-text">Say</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Real feedback from satisfied customers
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="bg-card border border-border rounded-xl p-6 hover:border-primary transition-all duration-300 transform hover:scale-105"
              data-testid={`testimonial-${index}`}
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mr-4">
                  <User className="w-6 h-6 text-background" />
                </div>
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </div>
              <div className="flex mb-3">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-muted-foreground">{testimonial.content}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
