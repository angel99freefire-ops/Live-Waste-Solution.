import { useState } from "react";
import { ChevronDown } from "lucide-react";

const faqs = [
  {
    question: "What types of waste can your suction bowser handle?",
    answer: "Our suction bowsers can handle various types of liquid waste including septic tank contents, industrial wastewater, and other non-hazardous liquid waste materials."
  },
  {
    question: "Is your mobile incinerator environmentally compliant?",
    answer: "Yes, our mobile incineration units are fully compliant with environmental regulations and equipped with advanced emission control systems to minimize environmental impact."
  },
  {
    question: "Do you offer emergency waste removal services?",
    answer: "Yes, we provide 24/7 emergency response services for urgent waste removal situations. Our rapid response team can be deployed quickly to handle spills, overflows, or other waste emergencies."
  },
  {
    question: "What industries do you serve?",
    answer: "We serve a wide range of industries including manufacturing, healthcare, hospitality, residential complexes, government facilities, and commercial establishments."
  },
  {
    question: "How do you ensure proper waste disposal?",
    answer: "We follow strict protocols and are certified by SEPA and BEPA. All waste is tracked from collection to final disposal, ensuring complete compliance with environmental regulations."
  }
];

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(2); // Emergency services open by default

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-20 bg-accent">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Frequently Asked <span className="gradient-text">Questions</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Get answers to common questions about our services
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto space-y-4">
          {faqs.map((faq, index) => (
            <div 
              key={index}
              className="bg-card border border-border rounded-xl overflow-hidden"
              data-testid={`faq-item-${index}`}
            >
              <button 
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-muted transition-colors"
                onClick={() => toggleFAQ(index)}
                data-testid={`faq-question-${index}`}
              >
                <span className="font-semibold">{faq.question}</span>
                <ChevronDown 
                  className={`w-5 h-5 transition-transform ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {openIndex === index && (
                <div 
                  className="px-6 pb-4 text-muted-foreground"
                  data-testid={`faq-answer-${index}`}
                >
                  <p>{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
