# Live Waste Solution - Modern Waste Management Website

## Overview

Live Waste Solution is a modern, dark-themed 3D website for a leading waste management company in Pakistan. The application is built as a full-stack web application with a React frontend and Express backend, designed to showcase comprehensive waste management services including mobile incineration, septic tank cleaning, suction bowser services, and various specialized waste handling solutions. The website features an interactive design with 3D animations, service showcases, client testimonials, and a contact system for potential customers.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
The frontend is built using React with TypeScript and follows a component-based architecture. The application uses Vite as the build tool and development server for fast hot module replacement and optimized builds.

**Component Structure:**
- **Layout Components**: Navigation, Footer for consistent site structure
- **Section Components**: Hero, Services, About, Testimonials, Contact, FAQ sections for modular page composition
- **UI Components**: Complete shadcn/ui component library with Radix UI primitives for consistent design system
- **Routing**: Wouter for lightweight client-side routing

**Styling System:**
- **Tailwind CSS**: Utility-first CSS framework for rapid UI development
- **Design Tokens**: CSS custom properties for consistent theming with dark mode support
- **Color Scheme**: Dark theme with vibrant green (#00FF88) primary and electric blue (#1E90FF) secondary colors
- **Component Variants**: Class Variance Authority for systematic component styling

### Backend Architecture
The backend follows an Express.js architecture with a modular routing system and abstracted storage layer.

**API Structure:**
- **RESTful Endpoints**: Contact form submission and retrieval endpoints
- **Middleware**: JSON parsing, request logging, and error handling
- **Storage Abstraction**: Interface-based storage system with in-memory implementation for development

**Development Setup:**
- **Hot Reloading**: TSX for TypeScript execution with automatic restart
- **Static Serving**: Vite integration for serving frontend assets in development
- **Build Process**: ESBuild for backend bundling and Vite for frontend optimization

### Data Storage Solutions
The application uses a flexible storage architecture that can be easily swapped between implementations.

**Database Schema:**
- **Users Table**: Basic user authentication structure (id, username, password)
- **Contact Submissions**: Form data storage (id, name, email, phone, message, timestamp)
- **Schema Validation**: Drizzle ORM with Zod integration for type-safe database operations

**Current Implementation:**
- **Development**: In-memory storage for rapid development and testing
- **Production Ready**: PostgreSQL configuration with Drizzle ORM and Neon Database integration
- **Migrations**: Drizzle Kit for database schema management

### Authentication and Authorization
Basic authentication structure is established but not currently implemented in the UI, focusing on the public-facing marketing website functionality.

**Prepared Infrastructure:**
- User schema with username/password fields
- Session management preparation with connect-pg-simple
- Extensible authentication system ready for future admin features

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18 with TypeScript, Wouter for routing, TanStack Query for state management
- **Build Tools**: Vite for frontend bundling, ESBuild for backend compilation, TSX for development execution
- **Styling**: Tailwind CSS with PostCSS, shadcn/ui component library, Radix UI primitives

### Database and ORM
- **Database**: PostgreSQL with Neon Database serverless hosting
- **ORM**: Drizzle ORM for type-safe database operations
- **Validation**: Zod for runtime type validation and schema generation
- **Migrations**: Drizzle Kit for database schema management

### UI and Design System
- **Component Library**: Complete shadcn/ui implementation with Radix UI primitives
- **Icons**: Lucide React for consistent iconography
- **Styling Utilities**: clsx and tailwind-merge for conditional styling, Class Variance Authority for component variants
- **Typography**: Custom font integration with Google Fonts (Inter, Architects Daughter, DM Sans, Fira Code, Geist Mono)

### Development and Production Tools
- **Replit Integration**: Vite plugins for Replit-specific development features (cartographer, dev banner, runtime error overlay)
- **Date Handling**: date-fns for date manipulation and formatting
- **Form Management**: React Hook Form with Hookform Resolvers for form validation
- **Development**: TypeScript for type safety, various ESLint and development dependencies